package com.example.wetherapp;

import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import android.Manifest;

import com.example.wetherapp.models.WeatherModel;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

private TextView latLanTextVeiw , addressTextView , timetextView, tempTextView,humidtyTextView,DescTextView;
private OkHttpClient client;
private Gson gson;
    private Handler handler = new Handler();
    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        latLanTextVeiw = findViewById(R.id.textView_LL);
        addressTextView = findViewById(R.id.textView_Geo);
        timetextView = findViewById(R.id.textView_Time);
        tempTextView = findViewById(R.id.textView_temp);
        humidtyTextView = findViewById(R.id.textView_humid);
        DescTextView = findViewById(R.id.textView_Desc);




        // Create a runnable to update the time
                runnable = new Runnable() {
            @Override
            public void run() {
                updateTime();
                handler.postDelayed(this, 1000); // Update every second
            }
        };

        // Start the runnable
        handler.post(runnable);

        int fine = ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION);
        int coarse = ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION);

        if(fine != PackageManager.PERMISSION_GRANTED){
            String[] ss = new String[1];
            ss[0] = Manifest.permission.ACCESS_FINE_LOCATION;
            requestPermissions(ss ,  999);

        }
        if(fine != PackageManager.PERMISSION_GRANTED){
            String[] ss = new String[1];
            ss[0] = Manifest.permission.ACCESS_COARSE_LOCATION;
            requestPermissions(ss ,  999);

        }

        LocationManager lm = (LocationManager)getSystemService(LOCATION_SERVICE);
        Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);

        double lat = loc.getLatitude();
        double lng = loc.getLongitude();

        latLanTextVeiw.setText("Lat : "+lat+", "+"Lan : "+lng);
        getAddressFromLatLng(lat,lng);
        fetchWeatherData();


    }
    private void updateTime() {
        // Get the current time
        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        // Set the current time to the TextView
        timetextView.setText("Time : "+currentTime);
    }

    private void getAddressFromLatLng(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());

        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                String addressString = address.getAddressLine(0); // If you need a single line address
                // You can also use address.getLocality(), address.getPostalCode(), etc.
                addressTextView.setText("Geo Address : "+addressString);
            } else {
                addressTextView.setText("Geo Address : No address found for the location");
            }
        } catch (IOException e) {
            e.printStackTrace();
            addressTextView.setText("Geo Address : Unable to get address for the location");
        }
    }

    private void fetchWeatherData() {
        String url = "https://api.openweathermap.org/data/2.5/forecast?id=524901&appid=1265dd4b6802d99aef572c675e6d570";

        client = new OkHttpClient();
        gson = new Gson();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String myResponse = response.body().string();
                    Log.d("CALL", "onResponse: " + myResponse);
                    final WeatherModel weatherModel = gson.fromJson(myResponse, WeatherModel.class);

                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            com.example.wetherapp.models.List item = weatherModel.getList().get(0);
                            tempTextView.setText("Temp : "+item.getMain().getTemp());
                            humidtyTextView.setText("Humidity : "+item.getMain().getHumidity());

                            DescTextView.setText("Descriiption : "+item.getWeather().get(0).getDescription());
                        }
                    });
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove the callbacks to prevent memory leaks
        handler.removeCallbacks(runnable);
    }


}